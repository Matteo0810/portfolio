## BUG
- [ ] Bug quand on ajoute une consommation ça reset le champ de numéro de chambre
- [ ] Problème avec le price spinner et quantity spinner

## TEST
- [ ] Ajouter un jeu de test