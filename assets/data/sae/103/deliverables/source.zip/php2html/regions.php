<?php

    $GLOBALS["config"] = "regions.conf";

    function get_region($region_id) {
        $data = NULL;
        $region_id = strtoupper($region_id);
        $file = file($GLOBALS["config"]);

        if(!$file) {
            echo "E: impossible d'ouvrir le fichier: ".$GLOBALS["config"];
            exit();
        }

        $i = 0;
        while($data == NULL && $i < sizeof($file)) {
            $line = explode(";", $file[$i]);
            [$id, $nom, $superifice, $population, $nb_depts] = $line;

            if($region_id == $id) {
                $data = array(
                    "region_id" => $id,
                    "nom_region" => $nom,
                    "superificie" => $superifice,
                    "population" => $population,
                    "nb_depts" => $nb_depts
                );
            }

            $i++;
        }

        return $data;
    }