<?php

require('regions.php');

/* VERIFICATION DES PARAMETRES */
function verifyFile($file): bool {
    $extension = explode('.', $file)[1];
    if($extension !== "dat")
        return true; // l'extension n'est pas valide
    return !file_exists($file);
}

function verifyParam($param): bool {
    return !isset($param);
}

// vérifier si le script contient bien tous les paramètres
$params = array_slice($argv, 1); // on retire le nom de la commande au début
if(sizeof(array_filter($params, 'verifyParam')) > 0) {
    echo "E: arguments invalides: syntaxes: ./page.php <comm.dat> <tableau.dat> <texte.dat>";
    exit();
}

// vérifier si les fichiers sont correctes et existent
$files = $params;
$invalid_files = array_filter($files, 'verifyFile');
if(sizeof($invalid_files) > 0) {
    echo "E: un des fichiers suivants sont introuvables/incorrectes: ".implode(',', $invalid_files);
    exit();
}

// on transforme nos chaîne contenant le nom des fichiers en contenu du fichier.
$files = array_map(function ($file) {
    return json_decode(file_get_contents($file));
}, $files);
/* VERIFICATION DES PARAMETRES */

$products = $files[1];
$texts = $files[2];
$comm = $files[0];
$region = get_region($texts->CODE);

if(!isset($region)) {
    echo "E: region introuvable";
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Document</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: sans-serif;
        }

        section {
            position: relative;
            height: 100vh;
        }

        img {
            border-radius: 10px;
        }

        table, td, th {
            border: 1px solid black;
        }

        .bottom {
            position: absolute;
            bottom: 0;
            width: 100%;
            text-align: center;
            min-height: 5rem;
        }

        a {
            display: block;
        }

        h1 {
            text-align: center;
            margin: 2em 0;
        }

        section:nth-child(2)>div {
            overflow: hidden;
            max-height: 45em;
            margin-bottom: 2em;
        }

        section:nth-child(3)>figure {
            display: inline-block;
            margin: 1em 1em;
        }
        section:nth-child(3)>figure>figcaption {
            text-align: center;
        }

        section:nth-child(4) {
            display: grid;
            justify-content: center;
        }

        @media print {
            section {
                border: 1px solid black;
                width: 8.26in;
                height: 11.66in;
                margin: 0;
                page-break-after: always;
            }
        }
    </style>
</head>
<body>

    <section>
        <h2>Nom: <?php echo $region["nom_region"]; ?></h2>
        <h3>Superficie: <?php echo $region["superificie"]; ?> km2</h3>
        <h3>Population: <?php echo $region["population"]; ?> habitants</h3>
        <h3>Nombre de départements: <?php echo $region["nb_depts"]; ?></h3>
        <img src="<?php echo $region["region_id"]; ?>.png" alt="<?php echo $region["nom_region"]; ?>">


        <div class="bottom">
            <?php echo date("d-m-Y H:i"); ?>
        </div>
    </section>

    <section>

        <div>
            <?php
            $month = date("m");
            $trimestre = ceil($month/4); // on recupère le trimestre
            $year = date("Y");

            echo "<h1>Résultats trimestriels 0".$trimestre."-".$year."</h1>";

            foreach($texts as $legend => $content) {
                if($legend !== "CODE" && strrpos($legend, "credits") === false) {
                    if(strrpos($legend, "sous_titre") !== false)
                        echo "<h3>".$content."</h3>";
                    else if(strrpos($legend, "titre") !== false)
                        echo "<h2>".$content."</h2>";
                    else
                        echo "<p>".$content."</p>";
                }
            }

            ?>

            <h3>Crédits</h3>

            <ul>
                <?php
                foreach($texts->credits_1 as $credit) {
                    $credit = substr($credit, 2);
                    $htmlCode = $credit;

                    // si la chaîne contient un lien (oui y'a plus simple c'est pas le plus opti)
                    if(strrpos($credit, "] (") !== false) {
                        $credit = substr($credit, 1, -1); // on retire le [ et le ) de la chaîne de caractère
                        $credit = explode('] (', $credit); // désolé pour ça, c'est horrible.
                        $htmlCode = " <a href='".$credit[1]."'>".$credit[0]."</a>";
                    }

                    echo "<li>".$htmlCode."</li>";
                }
                ?>
            </ul>
        </div>

        <table>
            <tr>
                <th scope="col">Nom du produit</th>
                <th scope="col">Ventes du trimestre</th>
                <th scope="col">Chiffre d'affaire du trimestre</th>
                <th scope="col">Ventes du même trimestre année précédente</th>
                <th scope="col">CA du même trimestre année précédente</th>
                <th scope="col">Evolution de CA en %</th>

            </tr>

            <?php

            foreach($products as $product) {
                $evolution = ($product->ca_trimestre/$product->ca_annee_precedente);
                $evolution = round($evolution, 2);
                $class = $evolution > 1 ? "good" : "bad";
                $evolution=($evolution*100)-100;
                $evolution = abs($evolution);

                echo "
                         <tr>
                            <td>".$product->nom_produit."</td>
                            <td>".$product->vente_trimestre."</td>
                            <td>".$product->ca_trimestre."</td>
                            <td>".$product->vente_annee_precedente."</td>
                            <td>".$product->ca_annee_precedente."</td>
                            <td class='".$class."'>".$evolution." %</td>
                         </tr>
                      ";
            }

            ?>

        </table>

        <div class="bottom">
            <?php echo date("d-m-Y H:i"); ?>
        </div>
    </section>

    <section>
        <h1>Nos meilleures vendeurs du trimestre</h1>

        <?php
        foreach (array_slice($comm->meilleurs_commerciaux, 0, 3) as $commercial) {
            $nickname = strtolower($commercial->nickname);
            echo '
                        <figure>
                            <img src="./photos/'.$nickname.'.png" alt="photo de '.$commercial->nom.'">
                            <figcaption>
                                '.$commercial->nom.'
                                '.$commercial->total_ventes.'
                            </figcaption>
                        </figure>
                    ';
        }

        ?>

        <div class="bottom">
            <?php echo date("d-m-Y H:i"); ?>
        </div>
    </section>

    <section>
        <a href="https://bigbrain.biz/<?php echo $region["region_id"] ?>">Lien vers le site fictif</a>
        <img src="./<?php echo $region["region_id"] ?>-qrcode.png" alt="Qr code">
        <div class="bottom">
            <?php echo date("d-m-Y H:i"); ?>
        </div>
    </section>

</body>

</html>
