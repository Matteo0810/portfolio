#!/bin/bash

IMAGE_DOCKER="bigpapoo/sae103-imagick" #déclaration constante 

if [[ $1 = "" || $2 = "" || $3 = "" ]]
then
    echo "Erreur de saisie, voici un modèle type de la commande à saisir: ./svgtopng.sh fic.svg fic.png ~/Chemin_absolu_hote"
    echo "Fin d'execution"
    exit 1
fi


if [[ "sudo docker images | egrep '$IMAGE_DOCKER'" = "" ]]  #test si l'image est présente ou non
then
    echo "ERREUR, l'image $IMAGE_DOCKER n'existe pas"
    echo "arrêt du processus"
    exit 1
fi

if ! test -f $1     #Vérifie si le fichier saisie (ici fic.svg) existe ou pas dans le répertoire 
then 
    echo "Le fichier $1 n'existe pas"
    echo "Fin d'execution"
    exit 1
fi



if [[ -f $2 ]]; then
    if [[ $4 = "-y" ]]; then
        echo "le fichier déjà existant sous le nom de $2 va être supprimé puis remplacé"
        rm -f $2
        echo "fichier supprimé"
    else
        read -p "Le fichier $2 existe déja, voulez vous le supprimer (o/n)" rep #Demande une saisie qui sera ajouté à la variable située derrière (ici rep)
        
        while [[ $rep != "o" && $rep != "n" ]]
        do
            echo "Erreur de saisie, Veuillez saisir o ou n"
            read rep  
        done
        if [[ "$rep" = "o" ]]
        then
            rm -f $2
        else
            echo "Votre requête n'a pas aboutie, arrêt du processus"
            exit 1
        fi  
    fi
fi

sudo docker container run -ti --rm -v $3:/work $IMAGE_DOCKER "magick $1 -grayscale Rec709Luminance -crop 600x550+0+0 -resize 200x200 $2" 
echo "Commande éxécutée avec succès"
 
