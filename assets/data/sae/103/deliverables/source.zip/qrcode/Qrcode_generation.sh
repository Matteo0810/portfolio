#!/bin/bash

IMAGE_DOCKER="bigpapoo/sae103-qrcode"  #déclaration constante

if [[ $1 = "" || $2 = "" || $3 = "" ]]  #test de paramètres oubliés lors de l'éxécution de la commande
then
    echo "ERREUR, la syntaxe a respecter est : ./Qrcode_generation.sh <nomDuFichier.png> <Texte> ~/Chemin_absolu_hote"
    exit 1
fi

if [[ "sudo docker images | egrep '$IMAGE_DOCKER'" = "" ]]  #test si l'image est présente ou non
then
    echo "ERREUR, l'image $IMAGE_DOCKER n'existe pas"
    exit 1
fi

if [[ -f "$1" ]]; then   #test de l'existence du fichier, puis demande de remplacement
    if [[ $4 = "-y" ]]; then
        echo "le fichier déjà existant sous le nom de $1 va être supprimé puis remplacé"
        rm -f $1
        echo "fichier supprimé"
    else  
        echo "ERREUR, Le fichier que vous essayez de créer existe déjà :"
        echo "Voulez vous supprimez le fichier existant et le remplacer ? o/n"
        read reponse
        while [[ $reponse != "o" && $reponse != "n" ]]
        do
            echo "Vous n'avez pas entrer une valeur correcte : entrez soit "o" pour supprimer soit "n" pour annuler"
            read reponse
        done
        if [[ "$reponse" = "o" ]]; then
            rm -f $1  #suppression
            echo "fichier supprimé"
        else
            echo "Votre requête n'a pas aboutie, arrêt du processus"
            exit 1
        fi
    fi
fi

sudo docker container run -ti -v $3:/work $IMAGE_DOCKER qrcode -o $1 "$2" 
echo "Commande éxécutée avec succès"