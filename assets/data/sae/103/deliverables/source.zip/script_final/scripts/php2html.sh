#!/bin/bash

IMAGE_DOCKER="bigpapoo/sae103-php"  #déclaration constante

if [[ $1 = "" || $2 = "" || $3 = "" ]]  #test de paramètres oubliés lors de l'éxécution de la commande
then
    echo "ERREUR, la syntaxe a respecter est : ./html2pdf.sh <nomDuFichier.php> <nomDuFichierCree.html> <cheminDuVolume> [-y]"
    echo "arrêt du processus"
    exit 1
fi

if [[ "docker images | egrep '$IMAGE_DOCKER'" = "" ]]  #test si l'image est présente ou non
then
    echo "ERREUR, l'image $IMAGE_DOCKER n'existe pas"
    echo "arrêt du processus"
    exit 1
fi

if [[ -f "$2" && $4 = "-y" ]]
then 
    # echo "le fichier déjà existant sous le nom de $2 va être supprimé puis remplacé"
    rm -f $2
    # echo "fichier supprimé"
elif test -f "$2"; then
    # echo "ERREUR, Le fichier que vous essayez de créer existe déjà :"
    # echo "Voulez vous supprimez le fichier existant et le remplacer ? o/n"
    read reponse
    while [[ $reponse != "o" && $reponse != "n" ]]
    do
        # echo "Vous n'avez pas entrer une valeur correcte : entrez soit "o" pour supprimer soit "n" pour annuler"
        read reponse
    done
    if test $reponse = "o"; then
        rm -f $2  #suppression
        # echo "fichier supprimé"
    else
        echo "Votre requête n'a pas aboutie, arrêt du processus"
        exit 1
    fi
fi


docker container run -ti --rm -v "$3":/work $IMAGE_DOCKER php -f $1 > "$2"
# echo "Commande éxécutée avec succès"