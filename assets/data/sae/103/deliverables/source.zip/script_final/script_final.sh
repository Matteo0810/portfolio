#!/bin/bash
TMP="tmp"
docker_volume=$1

# si le dossier n'existe pas on le crée, sinon on le recrée pour le vider (histoire de pas gêner)
if [[ -d "$TMP" ]]
then
  rm -r "$TMP"
fi
mkdir -p "$TMP"

echo "[!] Création/Réinitialisation du dossier $TMP"

# étape 1 : décoder les fichier textes
echo "Décodage des fichiers textes..."
for file in textes/*.txt
do
  mv -v "$file" "${file// /-}" > /dev/null 2> /dev/null # on fou à la poubelle les logs
  name=$(basename "$file")
  name=${name%.*}
  folder="$TMP"/"$name"

  if [[ ! -d "$folder" ]] 
  then
    mkdir -p "$folder"
  fi

  docker container run -ti --rm -v "$docker_volume":/work "bigpapoo/sae103-php" php -f scripts/generation_fichiers.php "$file" "$folder"
done
echo "Décodage des fichiers textes... FAIT"

# étape 2 : transformer les photos svg en png
echo "Transformation des photos svg en png... (Cela peut prendre du temps)"
mkdir -p "$TMP"/photos
for photo in photos/*.svg
do
  photo=$(basename "$photo")
  photo=${photo%.*}

  chmod +x scripts/svgtopng.sh
  ./scripts/svgtopng.sh photos/"$photo".svg "$TMP"/photos/"$photo".png "$docker_volume" -y
done
echo "Transformation des photos svg en png... FAIT"

# étape 3 : créer les qrcodes
echo "Génération des QRCodes..."
for file in textes/*.txt
do
      name=$(basename "$file")
      name=${name%.*}
      folder="$TMP"/"$name"
      region_id=$(egrep -i "^CODE=" "$file" | cut -d"=" -f2 | tr a-z A-Z)

      chmod +x scripts/qrcode_generation.sh
      ./scripts/qrcode_generation.sh "$folder/$region_id-qrcode.png" "https://bigbrain.biz/$region_id" "$docker_volume" -y
done
echo "Génération des QRCodes... FAIT"

# étape 4 : transformer les régions en fichier html
echo "Transformation des régions en fichier HTML..."
for file in textes/*.txt
do
  name=$(basename "$file")
  name=${name%.*}
  folder="$TMP"/"$name"

  chmod +x scripts/php2html.sh
  ./scripts/php2html.sh "page.php $folder/comm.dat $folder/tableau.dat $folder/texte.dat" "$folder"/"$name".html "$docker_volume" -y
done
echo "Transformation des régions en fichier HTML... FAIT"

# étape 5 : on créer les fichiers pdf
echo "Transformation du fichier HTML en fichier PDF..."
mkdir -p pdf
for file in textes/*.txt
do
  name=$(basename "$file")
  name=${name%.*}
  folder="$TMP"/"$name"
	
  chmod +x scripts/html2pdf.sh
  ./scripts/html2pdf.sh "$folder"/"$name".html pdf/"$name".pdf "$docker_volume" -y > /dev/null
done
echo "Transformation du fichier HTML en fichier PDF... FAIT"

# dernière étape: on créer le fichier zip et supprime le dossier tmp
echo "Création du fichier compressé et nettoyage..."
tar -czvf rendu.tar.gz pdf > /dev/null
rm -rf "$TMP" pdf
echo "Création du fichier compressé et nettoyage... FAIT"
